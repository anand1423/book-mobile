import { Box, Typography, Paper } from "@mui/material";
function HomePage() {
  const data = [
    {
      id: 1,
      firstName: "Emily",
      lastName: "Johnson",
      email: "emily.johnson@x.dummyjson.com",
      phone: "+81 965-431-3024",
      image: "https://dummyjson.com/icon/emilys/128",
      book: [
        {
          id: 1,
          title: "The Catcher in the Rye",
          author: "J.D. Salinger",
          genre: "Fiction",
          description:
            "The Catcher in the Rye is a novel by J.D. Salinger published in 1951. It is a story of teenage angst and alienation.",
          published: "1951-07-16",
          publisher: "Little, Brown and Company",
          progress: "75%",
          chapter: [
            { id: 1, title: "Chapter 1", process: "completed" },
            {
              id: 2,
              title: "Chapter 2",
              process: "completed",
            },
            {
              id: 3,
              title: "Chapter 3",
              process: "completed",
            },
            {
              id: 4,
              title: "Chapter 4",
              process: "incomplete",
            },
          ],
        },
      ],
    },
    {
      id: 2,
      firstName: "Michael",
      lastName: "Smith",
      email: "michael.williams@x.dummyjson.com",
      phone: "+49 258-627-6644",
      image: "https://dummyjson.com/icon/michaelw/128",
      book: [
        {
          id: 1,
          title: "The Catcher in the Rye",
          author: "J.D. Salinger",
          genre: "Fiction",
          description:
            "The Catcher in the Rye is a novel by J.D. Salinger published in 1951. It is a story of teenage angst and alienation.",
          published: "1951-07-16",
          publisher: "Little, Brown and Company",
          progress: "50%",
          chapter: [
            { id: 1, title: "Chapter 1", process: "completed" },
            {
              id: 2,
              title: "Chapter 2",
              process: "completed",
            },
            {
              id: 3,
              title: "Chapter 3",
              process: "incomplete",
            },
            {
              id: 4,
              title: "Chapter 4",
              process: "incomplete",
            },
          ],
        },
      ],
    },
  ];
  return (
    <Box>
      <Typography
        variant="h4"
        component="h2"
        sx={{ mb: 2, textAlign: "center" }}
      >
        Users Profile
      </Typography>
      {data.map((user) => (
        <Paper
          key={user.id}
          elevation={3}
          sx={{
            mb: 2,
            p: 2,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <img
              src={user.image}
              alt={user.firstName}
              style={{ width: "50px", height: "50px", borderRadius: "50%" }}
            />
            <Box sx={{ ml: 2 }}>
              <Typography variant="h6" component="h3">
                {user.firstName} {user.lastName}
              </Typography>
              <Typography variant="body1" component="p">
                {user.email}
              </Typography>
              <Typography variant="body1" component="p">
                {user.phone}
              </Typography>
            </Box>
          </Box>
          <Box>
            {user.book.map((book) => (
              <Box key={book.id} sx={{ mb: 2 }}>
                <Typography variant="h6" component="h4">
                  {book.title}
                </Typography>
                <Typography variant="body1" component="p">
                  {book.author}
                </Typography>
                <Typography variant="body1" component="p">
                  {book.genre}
                </Typography>
                <Typography variant="body1" component="p">
                  {book.description}
                </Typography>
                <Typography variant="body1" component="p">
                  {book.published}
                </Typography>
                <Typography variant="body1" component="p">
                  {book.publisher}
                </Typography>
                <Typography variant="body1" component="p">
                  {book.progress}
                </Typography>
                <Box>
                  {book.chapter.map((chapter) => (
                    <Box key={chapter.id} sx={{ mb: 1 }}>
                      <Typography variant="body1" component="p">
                        {chapter.title}
                      </Typography>
                      <Typography variant="body1" component="p">
                        {chapter.process}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              </Box>
            ))}
          </Box>
        </Paper>
      ))}
    </Box>
  );
}

export default HomePage;
